var SLIDE_CONFIG = {
  // Slide settings
  settings: {
    title: 'Continuum',
    subtitle: 'A JS (ES6) Virtual Machine Written in JS (ES3)',
    //eventInfo: {
    //  title: 'Google I/O',
    //  date: '6/x/2013'
    //},
    useBuilds: true,
    usePrettify: true,
    enableSlideAreas: true,
    enableTouch: true,
    fonts: [
      'Open Sans:regular,semibold,italic,italicsemibold',
      'Source Code Pro'
    ],
  },

  // Author information
  presenters: [{
    name: 'Brandon Benvie',
    company: 'Mozilla',
    twitter: '@benvie',
    www: 'http://benvie.github.io/continuum',
    github: 'https://github.com/Benvie/continuum'
  }]
};

